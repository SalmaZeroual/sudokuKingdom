import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/tournament_provider.dart';
import '../../config/theme.dart';
import '../../models/tournament_model.dart';
import '../tournament/tournament_game_screen.dart';
import '../tournament/tournament_leaderboard_screen.dart';

class TournamentModeScreen extends StatefulWidget {
  const TournamentModeScreen({Key? key}) : super(key: key);

  @override
  State<TournamentModeScreen> createState() => _TournamentModeScreenState();
}

class _TournamentModeScreenState extends State<TournamentModeScreen> {
  // Compte à rebours jusqu'à minuit
  late Timer _countdownTimer;
  Duration _timeUntilMidnight = Duration.zero;

  @override
  void initState() {
    super.initState();
    _updateCountdown();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) _updateCountdown();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<TournamentProvider>(context, listen: false).loadTournaments();
    });
  }

  void _updateCountdown() {
    final now = DateTime.now();
    final midnight = DateTime(now.year, now.month, now.day + 1);
    setState(() {
      _timeUntilMidnight = midnight.difference(now);
    });
  }

  @override
  void dispose() {
    _countdownTimer.cancel();
    super.dispose();
  }

  String get _countdownText {
    final h = _timeUntilMidnight.inHours.toString().padLeft(2, '0');
    final m = (_timeUntilMidnight.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_timeUntilMidnight.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tournois'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () =>
                Provider.of<TournamentProvider>(context, listen: false)
                    .loadTournaments(),
          ),
        ],
      ),
      body: Consumer<TournamentProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.isOffline && provider.tournaments.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.wifi_off, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    const Text(
                      'Pas de connexion',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Le tournoi nécessite une connexion internet.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 24),
                    OutlinedButton.icon(
                      onPressed: () => provider.loadTournaments(),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Réessayer'),
                    ),
                  ],
                ),
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: () => provider.loadTournaments(),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 16),

                  // ── Compte à rebours jusqu'à la prochaine rotation ──
                  _buildCountdownBanner(),
                  const SizedBox(height: 24),

                  _buildInfoCard(),
                  const SizedBox(height: 28),

                  Text(
                    'Choisissez votre niveau',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 16),

                  _buildTournamentsGrid(provider),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── Widgets ────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.yellow.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.emoji_events, color: AppColors.yellow, size: 32),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Tournois Quotidiens',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'Nouvelle grille chaque jour à minuit',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppColors.gray500,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCountdownBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: const [
              Icon(Icons.timelapse, color: AppColors.yellow, size: 20),
              SizedBox(width: 8),
              Text(
                'Nouvelle grille dans',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
          Text(
            _countdownText,
            style: const TextStyle(
              color: AppColors.yellow,
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.blue.withOpacity(0.1),
            AppColors.purple.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.blue.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: AppColors.blue, size: 24),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'Chaque tournoi dure 24h. Tous les joueurs partagent la même grille par niveau !',
              style: TextStyle(color: AppColors.gray700, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTournamentsGrid(TournamentProvider provider) {
    final difficulties = [
      {
        'level': 'Facile',
        'difficulty': 'facile',
        'color': AppColors.green,
        'xp': '50',
      },
      {
        'level': 'Moyen',
        'difficulty': 'moyen',
        'color': AppColors.blue,
        'xp': '100',
      },
      {
        'level': 'Difficile',
        'difficulty': 'difficile',
        'color': AppColors.orange,
        'xp': '150',
      },
      {
        'level': 'Extrême',
        'difficulty': 'extreme',
        'color': AppColors.red,
        'xp': '200',
      },
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.82,
      ),
      itemCount: difficulties.length,
      itemBuilder: (context, index) {
        final diff = difficulties[index];
        final tournament =
            provider.getTournamentByDifficulty(diff['difficulty'] as String);
        final hasJoined =
            tournament != null && provider.hasJoinedTournament(tournament.id);
        final hasFinished =
            tournament != null && provider.hasFinishedTournament(tournament.id);

        return _buildTournamentCard(
          level: diff['level'] as String,
          difficulty: diff['difficulty'] as String,
          color: diff['color'] as Color,
          xp: diff['xp'] as String,
          tournament: tournament,
          hasJoined: hasJoined,
          hasFinished: hasFinished,
          provider: provider,
        );
      },
    );
  }

  Widget _buildTournamentCard({
    required String level,
    required String difficulty,
    required Color color,
    required String xp,
    required TournamentModel? tournament,
    required bool hasJoined,
    required bool hasFinished,
    required TournamentProvider provider,
  }) {
    return GestureDetector(
      onTap: () =>
          _handleTournamentTap(tournament, difficulty, hasJoined, hasFinished, provider),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color, color.withOpacity(0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.emoji_events,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    level,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$xp XP',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withOpacity(0.9),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (tournament != null)
                    Row(
                      children: [
                        Icon(Icons.people, size: 14, color: Colors.white.withOpacity(0.9)),
                        const SizedBox(width: 4),
                        Text(
                          '${tournament.participants} joueurs',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.white.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            hasFinished
                                ? Icons.leaderboard
                                : hasJoined
                                    ? Icons.play_arrow
                                    : Icons.emoji_events,
                            color: color,
                            size: 14,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            hasFinished
                                ? 'Classement'
                                : hasJoined
                                    ? 'Continuer'
                                    : 'Participer',
                            style: TextStyle(
                              color: color,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Badge "✓ Inscrit"
            if (hasJoined)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.green,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    '✓',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleTournamentTap(
    TournamentModel? tournament,
    String difficulty,
    bool hasJoined,
    bool hasFinished,
    TournamentProvider provider,
  ) async {
    if (tournament == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Aucun tournoi $difficulty actif pour le moment'),
          backgroundColor: AppColors.orange,
        ),
      );
      return;
    }

    // ✅ Terminé → Classement
    if (hasFinished) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => TournamentLeaderboardScreen(tournament: tournament),
        ),
      );
      return;
    }

    // ✅ Rejoint mais pas terminé → Continuer la partie
    if (hasJoined) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => TournamentGameScreen(tournament: tournament),
        ),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rejoindre le tournoi ?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Tournoi du jour : ${tournament.name}'),
            const SizedBox(height: 8),
            Text('${tournament.participants} participants'),
            const SizedBox(height: 8),
            Text('Temps restant : $_countdownText'),
            const SizedBox(height: 16),
            const Text(
              '⚠️ Vous ne pourrez participer qu\'une seule fois par tournoi !',
              style: TextStyle(
                color: AppColors.red,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.yellow,
            ),
            child: const Text('Participer'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final success = await provider.joinTournament(tournament.id);

    if (!mounted) return;

    if (success) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => TournamentGameScreen(tournament: tournament),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Impossible de rejoindre le tournoi. Réessaie.'),
          backgroundColor: AppColors.red,
        ),
      );
    }
  }
}